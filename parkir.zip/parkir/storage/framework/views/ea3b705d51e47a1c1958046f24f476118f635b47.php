<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/user-page.css')); ?>">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body>
    <?php if(Auth::user()->role == 1): ?>
        <h1>User Page</h1>

        <?php if(session('success')): ?>
            <p><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <form action="<?php echo e(route('check-in')); ?>" method="POST">

            <?php echo csrf_field(); ?>
            <div class="container1">
                <label>Plate Number : </label>
                <input type="text" placeholder="Plate" name="plate" required>
                <br>
            <button style="border-radius: 5px" type="submit" class="btn btn-outline-primary">Check-in</button>
        </div>
        </form>


        <form action="<?php echo e(route('check-out')); ?>" method="POST">

            <?php echo csrf_field(); ?>
            <div class="container1">
                <label>Unique Code : </label>
                <input type="text" placeholder="Code" name="code" required>
                <br>
            <button style="border-radius: 5px" type="submit" class="btn btn-outline-primary">Check-out</button>
        </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>

        <?php if(session('time')): ?>
            <div class="alert alert-success">
                Total Price : <?php echo e(session('time')); ?>

            </div>
        <?php endif; ?>

    <?php endif; ?>


    
    <?php if(Auth::user()->role == 2): ?>

    <form action="<?php echo e(route('date-filter')); ?>" method="POST">
        
        <?php echo csrf_field(); ?>
        <div class="admin-choice">
            <label for="start_date">Start date:</label>
            <br>
            <input type="date" id="start_date" name="start_date">
        </div>
        <br>
        <div class="admin-choice">
            <label for="end_date">End Date:</label>
            <br>
            <input type="date" id="end_date" name="end_date">
        </div>

        <div class="admin-choice">
            <button style="border-radius: 5px margin:20px;" type="submit">Filter</button>
        </div>
        </form>

        <?php if(!is_null($getAllUser)): ?>
            <table class="table table-dark">
                <thead>
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Park In</th>
                    <th scope="col">Park Out</th>
                    <th scope="col">Code</th>
                    <th scope="col">Plate Number</th>
                  </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $getAllUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($user->id); ?></th>
                        <td><?php echo e($user->park_in); ?></td>
                        <td><?php echo e($user->park_out); ?></td>
                        <td><?php echo e($user->code); ?></td>
                        <td><?php echo e($user->plate_number); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

                <a href="<?php echo e(route('export-parking')); ?>" class="btn btn-success" style="margin: 20px">Export</a>
        <?php endif; ?>
    <?php endif; ?>
    <div class="logout">
        <button style="btn btn-outline-primary">
            <a href="/logout" >Logout</a>
        </button>
    </div>
    </body>
</html>
<?php /**PATH C:\Users\drake\Documents\Bounche\backend\parkir\resources\views//user-page.blade.php ENDPATH**/ ?>