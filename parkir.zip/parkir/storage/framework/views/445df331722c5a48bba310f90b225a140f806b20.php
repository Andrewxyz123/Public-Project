<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }

            .container{
                align-items: center;
                text-align: center;
            }
        </style>
    </head>
    <body class="antialiased">
        <h1>Login Page</h1>
        <form action="<?php echo e(route('login')); ?>" method="POST">

            <?php echo csrf_field(); ?>
            <div class="container">
                <label>Email : </label>
                <input type="email" placeholder="Email" name="email" required>
                <br>
                <label>Password : </label>
                <input type="password" placeholder="Password" name="password" required>
                <br>
                <button class="btn btn-outline-dark" style="border-radius: 5px; font-size:50px;" type="submit">Login</button>
            </div>
    
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
    </body>
</html>
<?php /**PATH C:\Users\drake\Documents\Bounche\backend\parkir\resources\views/login.blade.php ENDPATH**/ ?>